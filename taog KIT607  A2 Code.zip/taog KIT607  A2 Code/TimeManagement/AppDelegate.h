//
//  AppDelegate.h
//  TimeManagement
//
//  Created by kit305 on 14/5/17.
//  Copyright © 2017 utas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

